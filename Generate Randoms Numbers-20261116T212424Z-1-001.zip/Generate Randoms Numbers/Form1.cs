﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private byte Counter = 9;

        private void Form1_Load(object sender, EventArgs e)
        {
            txtMinNumber.Text = "1";
            txtMaxNumber.Text = "100";
            label5.Text = Counter.ToString();
            btnRestAttemps.Enabled = false;

        }

     

        private void btnRestAttemps_Click_1(object sender, EventArgs e)
        {   
           
            Counter = 9;
            label5.Text = Counter.ToString();
            btnRestAttemps.Enabled = false;
        }

        private void btnGenerateNumber_Click(object sender, EventArgs e)
        {
            try
            {
                int minNumber = Convert.ToInt32(txtMinNumber.Text);
                int maxNumber = Convert.ToInt32(txtMaxNumber.Text);

                if (Counter == 0)
                {
                    MessageBox.Show("You have reached the maximum number of attempts.");
                    btnRestAttemps.Enabled = true;
                    return;
                }

                Random random = new Random();
                int randomNumber = random.Next(minNumber, maxNumber + 1);

                lblResult.Text = randomNumber.ToString();
                Counter--;
                label5.Text = Counter.ToString();

            }
            catch (Exception)
            {

                MessageBox.Show("Please enter valid numbers for Min and Max.");

            }
        }
    }
}
